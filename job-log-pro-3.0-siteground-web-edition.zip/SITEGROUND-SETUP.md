# Deploy Job Log Pro 3.0 on SiteGround GoGeek

Recommended production hostname:

`https://app.easysafetysigns.co.uk`

Your WooCommerce site remains separate at its existing domain. Job Log Pro is deployed as its own Node.js Project and uses its own PostgreSQL database credentials.

## 1. Create the Node.js Project

In SiteGround:

1. Open **Client Area → Websites → Node.js Projects**.
2. Choose **Add New Project**.
3. Deploy by ZIP for the first installation, or connect a GitHub repository if you want automatic redeployment on every push.
4. Select a current Node.js runtime (Node 20+; Node 22 is suitable).
5. Use npm as the package manager.
6. The project uses `npm start` and `server.js` as its runtime entry point.
7. No frontend build/output directory is required; the Node server serves the static UI itself.

SiteGround initially assigns a temporary domain. Use it for the first test.

## 2. Create PostgreSQL

From the Node.js project's Site Tools create a PostgreSQL database and database user.

Record the connection details and create a `DATABASE_URL` value such as:

`postgresql://USER:PASSWORD@HOST:5432/DATABASE`

Do not put database credentials inside source files.

## 3. Add environment variables

In **Site Tools → Node.js → Environment Variables**, add the values from `.env.example`.

Minimum required:

- `NODE_ENV=production`
- `APP_BASE_URL=https://<temporary-domain>` initially
- `DATABASE_URL=...`
- `DATABASE_SSL=require`
- `SESSION_COOKIE_SECURE=true`
- `APP_ENCRYPTION_KEY=<64 hex characters>`
- `BOOTSTRAP_ADMIN_EMAIL=...`
- `BOOTSTRAP_ADMIN_NAME=...`
- `BOOTSTRAP_ADMIN_PASSWORD=<strong temporary password>`

Generate a 64-character encryption key locally with:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Never share or commit this key. Back it up securely: it is required to decrypt stored integration tokens.

## 4. Run database migrations

SiteGround provides SSH access for managed Node.js Projects and npm/npx commands may be used for migrations.

After deployment, connect by SSH and run from the project directory:

```bash
npm run migrate
npm run seed
```

`seed` creates the Easy Safety Signs organisation, workflow statuses, and the bootstrap administrator if `BOOTSTRAP_ADMIN_PASSWORD` is set.

After signing in, change the bootstrap password. Then remove `BOOTSTRAP_ADMIN_PASSWORD` from the environment variables.

## 5. Test on the temporary domain

Open:

`https://<temporary-domain>/api/health`

Expected response:

```json
{"ok":true,"version":"3.0.0"}
```

Then sign into the normal web UI.

## 6. Assign app.easysafetysigns.co.uk

When the temporary-domain test is successful:

1. Go to **Client Area → Websites → Node.js Projects**.
2. Open the project's Actions menu.
3. Choose **Change Primary Domain**.
4. Assign `app.easysafetysigns.co.uk`.
5. Enable/verify SiteGround SSL and HTTPS enforcement.
6. Change `APP_BASE_URL` to `https://app.easysafetysigns.co.uk` and redeploy/restart if SiteGround requires it.

## 7. Microsoft 365

Follow `docs/MICROSOFT-365.md` after the final custom domain is active. The OAuth redirect URL must match the final `APP_BASE_URL`.

## 8. WooCommerce

Follow `docs/WOOCOMMERCE.md` to create the signed order-paid webhook.

## 9. Migrate the Windows database (optional)

See `docs/WINDOWS-MIGRATION.md`.

## Recommended update method

For active development, connect the Node.js Project to a private GitHub repository. SiteGround can rebuild/redeploy on each push. ZIP deployment is also supported but every update must be uploaded manually.

## Operational notes

- Job Log Pro uses normal HTTPS request/response traffic and does not require WebSockets.
- Uploaded assets are currently stored inside PostgreSQL (`bytea`) so app redeployments do not erase them.
- SiteGround build/runtime logs should be checked after every deployment.
- Keep older successful builds only as long as you need them; SiteGround notes that old builds consume inode quota.
