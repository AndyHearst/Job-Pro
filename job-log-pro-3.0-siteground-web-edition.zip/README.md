# Job Log Pro 3.0 — SiteGround Web Edition

Production-oriented Node.js/PostgreSQL rebuild of Job Log Pro for SiteGround GoGeek Node.js Projects.

## Architecture

The core commercial/production model is deliberately separated:

**Customer → Quote → Quote Items → optional Sales Order → Sales Order Items → Production Jobs → Proof/Production → Invoice → Payment**

A production Job may be created directly from a Quote item or from a Sales Order item. This matches the observed ShopVox reference behaviour while keeping Job Log Pro's own implementation, branding, source code and data model.

## Included in 3.0

- Multi-tenant PostgreSQL schema (organisation scoped)
- Secure staff login and PostgreSQL-backed sessions
- Roles: administrator, manager, sales, designer, production, installer, accounts
- Dashboard for Quotes, Sales Orders, Invoices and Jobs
- ShopVox-reference-style dense list views
- Customer records
- Quote creation and line items
- Direct Job creation from Quote items
- Quote → Sales Order conversion
- Sales Order item → Production Job creation
- Invoice creation from Sales Orders
- Payments and invoice balances
- Server-generated invoice PDFs
- Tasks and notes foundations
- Microsoft 365 OAuth / Microsoft Graph inbox sync and sending
- Optional Microsoft 365 shared mailbox
- WooCommerce signed webhook import into Sales Orders
- Optional automatic production Job creation for WooCommerce orders
- Public quote approval links
- Audit/activity table
- AES-256-GCM encrypted integration tokens
- Legacy Windows/SQLite export and PostgreSQL import tooling
- SiteGround deployment documentation

## Requirements

- Node.js 20 or later
- PostgreSQL
- SiteGround GrowBig, GoGeek or Cloud Node.js Project, or another Node/PostgreSQL host

## Local commands

```bash
npm install
npm run migrate
npm run seed
npm start
```

For SiteGround follow `SITEGROUND-SETUP.md`.

## Important migration note

Microsoft 365 OAuth tokens from the Windows version are intentionally **not** migrated. The web edition uses a different server-side encryption key and public HTTPS callback, so Microsoft 365 should be reconnected after deployment.

## Production limitations / next modules

Version 3.0 establishes the web platform and the reference architecture. It does not claim complete ShopVox feature parity. Planned follow-on modules include product formula editor, advanced rigid-sheet nesting, full proof file workflow, installation/mobile workflow, purchase orders/inventory, granular saved views, accounting integrations, and richer reporting.

## Health endpoint

`GET /api/health` returns the deployed version and can be used for a simple availability check.
