# Job Log Pro 3.0 architecture

## Core entities

```text
Organisation
  ├─ Users
  ├─ Customers
  │   └─ Contacts
  ├─ Products
  │   └─ Product Components
  ├─ Quotes
  │   └─ Quote Items ─────────────┐
  │       └─ direct Production Job│
  ├─ Sales Orders                │
  │   └─ Sales Order Items ──────┼─> Production Jobs
  │                              │     ├─ Proofs
  │                              │     ├─ Tasks / Notes / Assets
  │                              │     └─ Production status
  ├─ Invoices <──────────────────┘
  │   └─ Payments
  ├─ Emails
  └─ Integrations / Audit
```

## Why both Quote → Job and Sales Order → Job exist

The reference screenshots show production Jobs can be created from Quote line items before the quote has been converted to an Order. Job Log Pro therefore models a Job's source explicitly (`quote`, `sales_order`, or `direct`) instead of assuming every Job belongs to a Sales Order.

Normal Easy Safety Signs ecommerce work should normally use Sales Orders. Direct Quote Jobs remain available for the workflows where production needs to begin before an order document is created.

## Hosting model

```text
Browser / mobile
     |
 HTTPS
     |
SiteGround Node.js Project
     |
     +---- PostgreSQL
     +---- Microsoft Graph
     +---- WooCommerce signed webhooks
```

No persistent WebSocket connection is required. The application is designed for the request/response model suitable for SiteGround shared Node.js hosting.
