const fs=require('fs'),path=require('path'),crypto=require('crypto');
process.env.APP_ENCRYPTION_KEY='11'.repeat(32);
const {encrypt,decrypt}=require('../src/crypto');
const {hashToken,hmacSha256Base64,timingSafeEqualText,ref}=require('../src/utils');
function ok(v,msg){if(!v)throw new Error(msg)}
ok(decrypt(encrypt('secret-token'))==='secret-token','encryption round-trip failed');
ok(hashToken('abc')===crypto.createHash('sha256').update('abc').digest('hex'),'token hashing failed');
const sig=hmacSha256Base64('secret',Buffer.from('{"id":1}')); ok(timingSafeEqualText(sig,sig),'HMAC comparison failed');
ok(ref('J',42)==='J-00042','reference numbering failed');
for(const f of ['server.js','migrations/001_core.sql','public/index.html','public/app.js','SITEGROUND-SETUP.md'])ok(fs.existsSync(path.join(__dirname,'..',f)),`missing ${f}`);
console.log('Job Log Pro 3.0 static self-test passed.');
