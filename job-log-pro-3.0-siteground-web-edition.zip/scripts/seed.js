const bcrypt = require('bcryptjs');
const { getPool } = require('../src/db');
(async () => {
  const db = getPool();
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    let org = (await client.query("SELECT * FROM organisations WHERE slug='easy-safety-signs'")).rows[0];
    if (!org) org = (await client.query("INSERT INTO organisations(name,slug,currency,vat_rate) VALUES('Easy Safety Signs','easy-safety-signs','GBP',20) RETURNING *")).rows[0];
    const email = process.env.BOOTSTRAP_ADMIN_EMAIL || 'admin@easysafetysigns.co.uk';
    const name = process.env.BOOTSTRAP_ADMIN_NAME || 'Administrator';
    const pw = process.env.BOOTSTRAP_ADMIN_PASSWORD;
    if (pw) {
      const hash = await bcrypt.hash(pw, 12);
      await client.query(`INSERT INTO users(organisation_id,name,email,role,password_hash,must_change_password)
        VALUES($1,$2,$3,'administrator',$4,true)
        ON CONFLICT(organisation_id,email) DO NOTHING`, [org.id,name,email,hash]);
    }
    const statuses = [
      ['design','Artwork/Design',10,'#4aa3ff',false],['internal_review','Internal Review',20,'#7357d1',false],['customer_review','Customer Review',30,'#8b5cf6',false],
      ['production','Production',40,'#16a8e6',false],['finishing','Finishing',50,'#f0a500',false],['qc','Quality Check',60,'#f97316',false],
      ['ready','Ready / Delivered',70,'#22c55e',false],['on_hold','On Hold',80,'#ef4444',false],['completed','Completed',90,'#16a34a',true]
    ];
    for (const [code,n,sort,colour,terminal] of statuses) await client.query(`INSERT INTO workflow_statuses(organisation_id,code,name,sort_order,colour,terminal) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(organisation_id,code) DO NOTHING`,[org.id,code,n,sort,colour,terminal]);
    await client.query('COMMIT');
    console.log(`Seed complete for ${org.name}.`);
    if (!pw) console.log('No BOOTSTRAP_ADMIN_PASSWORD set; no admin user was created.');
  } catch(e) { await client.query('ROLLBACK'); console.error(e); process.exitCode=1; }
  finally { client.release(); await db.end(); }
})();
