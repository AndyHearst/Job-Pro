const fs = require('fs');
const path = require('path');
const { getPool } = require('../src/db');

(async () => {
  const pool = getPool();
  const client = await pool.connect();
  try {
    await client.query('CREATE TABLE IF NOT EXISTS schema_migrations(version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
    const dir = path.join(__dirname, '..', 'migrations');
    const files = fs.readdirSync(dir).filter(x => x.endsWith('.sql')).sort();
    for (const file of files) {
      const version = file.split('_')[0];
      const done = await client.query('SELECT 1 FROM schema_migrations WHERE version=$1', [version]);
      if (done.rowCount) continue;
      console.log(`Applying migration ${file}`);
      await client.query('BEGIN');
      await client.query(fs.readFileSync(path.join(dir, file), 'utf8'));
      await client.query('INSERT INTO schema_migrations(version) VALUES($1) ON CONFLICT DO NOTHING', [version]);
      await client.query('COMMIT');
    }
    console.log('Migrations complete.');
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error(e); process.exitCode = 1;
  } finally { client.release(); await pool.end(); }
})();
