# Changelog

## 3.0.0 — SiteGround Web Edition

- Rebuilt Python/SQLite backend as Node.js/PostgreSQL.
- Added SiteGround-managed deployment architecture.
- Added database migrations and tenant-scoped relational model.
- Preserved Quote → Sales Order → Job workflow and added direct Quote-item Jobs based on reference screenshots.
- Added ShopVox-reference-style dashboard/list/detail UI patterns without copying proprietary code or branding.
- Added Microsoft 365 OAuth/Graph integration.
- Added signed WooCommerce order webhook import.
- Added public quote acceptance.
- Added invoice PDFs and payment balances.
- Added Windows SQLite export + PostgreSQL legacy import tooling.
