const { query } = require('./db');
const { encrypt, decrypt } = require('./crypto');
const { token } = require('./utils');

const GRAPH = 'https://graph.microsoft.com/v1.0';
function cfg() {
  return {
    tenant: process.env.MICROSOFT_TENANT_ID || 'common',
    clientId: process.env.MICROSOFT_CLIENT_ID || '',
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET || '',
    base: (process.env.APP_BASE_URL || '').replace(/\/$/, ''),
    sharedMailbox: process.env.MICROSOFT_SHARED_MAILBOX || ''
  };
}
function configured() { const c=cfg(); return !!(c.clientId && c.clientSecret && c.base); }
function redirectUri(){ return `${cfg().base}/api/integrations/microsoft365/callback`; }
function scopes(){ const shared=!!cfg().sharedMailbox; const x=['openid','profile','offline_access','User.Read','Mail.Read','Mail.Send']; if(shared)x.push('Mail.Read.Shared','Mail.Send.Shared'); return x.join(' '); }

async function saveIntegration(orgId, config, secrets) {
  await query(`INSERT INTO integrations(organisation_id,provider,config_json,secrets_encrypted,active,updated_at)
    VALUES($1,'microsoft365',$2::jsonb,$3,true,now())
    ON CONFLICT(organisation_id,provider) DO UPDATE SET config_json=EXCLUDED.config_json,secrets_encrypted=EXCLUDED.secrets_encrypted,active=true,updated_at=now()`,
    [orgId, JSON.stringify(config || {}), encrypt(JSON.stringify(secrets || {}))]);
}
async function loadIntegration(orgId){const r=await query("SELECT * FROM integrations WHERE organisation_id=$1 AND provider='microsoft365' AND active=true",[orgId]); const row=r.rows[0]; if(!row)return null; let secrets={}; try{secrets=JSON.parse(decrypt(row.secrets_encrypted)||'{}')}catch{} return {...row,secrets};}

async function tokenRequest(params){const c=cfg(); const url=`https://login.microsoftonline.com/${encodeURIComponent(c.tenant)}/oauth2/v2.0/token`; const body=new URLSearchParams(params); const res=await fetch(url,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body}); const data=await res.json(); if(!res.ok) throw new Error(data.error_description||data.error||'Microsoft token request failed'); return data;}

async function start(orgId){ if(!configured()) throw Object.assign(new Error('Microsoft 365 environment variables are not configured'),{status:400}); const state=token(24); await saveIntegration(orgId,{oauth_state:state,shared_mailbox:cfg().sharedMailbox},{state_created_at:new Date().toISOString()}); const c=cfg(); const u=new URL(`https://login.microsoftonline.com/${encodeURIComponent(c.tenant)}/oauth2/v2.0/authorize`); u.searchParams.set('client_id',c.clientId); u.searchParams.set('response_type','code'); u.searchParams.set('redirect_uri',redirectUri()); u.searchParams.set('response_mode','query'); u.searchParams.set('scope',scopes()); u.searchParams.set('state',state); return u.toString(); }

async function callback(orgId, code, state){const row=await loadIntegration(orgId); if(!row || row.config_json.oauth_state!==state) throw Object.assign(new Error('OAuth state mismatch'),{status:400}); const t=await tokenRequest({client_id:cfg().clientId,client_secret:cfg().clientSecret,grant_type:'authorization_code',code,redirect_uri:redirectUri(),scope:scopes()}); const me=await fetch(`${GRAPH}/me`,{headers:{authorization:`Bearer ${t.access_token}`}}).then(r=>r.json()); await saveIntegration(orgId,{account_email:me.mail||me.userPrincipalName||'',shared_mailbox:cfg().sharedMailbox},{access_token:t.access_token,refresh_token:t.refresh_token,expires_at:Date.now()+((t.expires_in||3600)-120)*1000}); return me;}

async function accessToken(orgId){const row=await loadIntegration(orgId); if(!row) throw Object.assign(new Error('Microsoft 365 is not connected'),{status:400}); let s=row.secrets||{}; if(s.access_token && Number(s.expires_at||0)>Date.now()) return {token:s.access_token,row}; if(!s.refresh_token) throw Object.assign(new Error('Microsoft 365 requires reconnecting'),{status:400}); const t=await tokenRequest({client_id:cfg().clientId,client_secret:cfg().clientSecret,grant_type:'refresh_token',refresh_token:s.refresh_token,redirect_uri:redirectUri(),scope:scopes()}); s={access_token:t.access_token,refresh_token:t.refresh_token||s.refresh_token,expires_at:Date.now()+((t.expires_in||3600)-120)*1000}; await saveIntegration(orgId,row.config_json,s); return {token:s.access_token,row:{...row,secrets:s}};}

async function graph(orgId,path,opts={}){const {token:at}=await accessToken(orgId); const res=await fetch(`${GRAPH}${path}`,{...opts,headers:{authorization:`Bearer ${at}`,'content-type':'application/json',...(opts.headers||{})}}); if(res.status===204)return null; const data=await res.json().catch(()=>({})); if(!res.ok) throw new Error(data?.error?.message||`Microsoft Graph ${res.status}`); return data;}
function mailboxPath(){return cfg().sharedMailbox?`/users/${encodeURIComponent(cfg().sharedMailbox)}`:'/me';}

async function syncInbox(orgId){const base=mailboxPath(); const data=await graph(orgId,`${base}/mailFolders/inbox/messages?$top=50&$orderby=receivedDateTime%20desc&$select=id,internetMessageId,subject,from,toRecipients,ccRecipients,receivedDateTime,isRead,bodyPreview,conversationId`); let imported=0; for(const m of data.value||[]){const from=m.from?.emailAddress?.address||''; const to=(m.toRecipients||[]).map(x=>x.emailAddress?.address||'').filter(Boolean).join(', '); const cc=(m.ccRecipients||[]).map(x=>x.emailAddress?.address||'').filter(Boolean).join(', '); const id=m.internetMessageId||m.id; const exists=await query('SELECT id FROM email_messages WHERE organisation_id=$1 AND provider_message_id=$2',[orgId,id]); if(exists.rowCount) continue; const customer=(await query('SELECT id FROM customers WHERE organisation_id=$1 AND lower(email)=lower($2) ORDER BY id LIMIT 1',[orgId,from])).rows[0]; let entityType='',entityId=null; const subj=m.subject||''; for(const [re,type,table,col] of [[/\bJ-(\d+)\b/i,'job','jobs','job_number'],[/\bSO-(\d+)\b/i,'sales_order','sales_orders','order_number'],[/\bQ-(\d+)\b/i,'quote','quotes','quote_number'],[/\bINV-(\d+)\b/i,'invoice','invoices','invoice_number']]){const mm=subj.match(re); if(mm){const full=mm[0].toUpperCase(); const rr=await query(`SELECT id FROM ${table} WHERE organisation_id=$1 AND ${col}=$2 LIMIT 1`,[orgId,full]); if(rr.rowCount){entityType=type;entityId=rr.rows[0].id;break;}}}
      await query(`INSERT INTO email_messages(organisation_id,direction,account_email,from_address,to_addresses,cc_addresses,subject,body_text,provider_message_id,thread_key,status,unread,customer_id,entity_type,entity_id,received_at)
      VALUES($1,'in',$2,$3,$4,$5,$6,$7,$8,$9,'received',$10,$11,$12,$13,$14)`,[orgId,cfg().sharedMailbox||'',from,to,cc,subj,m.bodyPreview||'',id,m.conversationId||id,!m.isRead,customer?.id||null,entityType,entityId,m.receivedDateTime||new Date()]); imported++; }
  return {imported,total:(data.value||[]).length}; }

async function sendMail(orgId,{to,cc='',subject,body,attachments=[]}){const recipients=String(to||'').split(/[;,]/).map(x=>x.trim()).filter(Boolean).map(address=>({emailAddress:{address}})); if(!recipients.length)throw Object.assign(new Error('Recipient required'),{status:400}); const ccs=String(cc||'').split(/[;,]/).map(x=>x.trim()).filter(Boolean).map(address=>({emailAddress:{address}})); const message={subject,body:{contentType:'HTML',content:body||''},toRecipients:recipients,ccRecipients:ccs}; if(attachments.length)message.attachments=attachments.map(a=>({'@odata.type':'#microsoft.graph.fileAttachment',name:a.name,contentType:a.contentType||'application/octet-stream',contentBytes:Buffer.isBuffer(a.data)?a.data.toString('base64'):String(a.data||'')})); await graph(orgId,`${mailboxPath()}/sendMail`,{method:'POST',body:JSON.stringify({message,saveToSentItems:true})}); await query(`INSERT INTO email_messages(organisation_id,direction,account_email,from_address,to_addresses,cc_addresses,subject,body_text,status,unread,sent_at) VALUES($1,'out',$2,$2,$3,$4,$5,$6,'sent',false,now())`,[orgId,cfg().sharedMailbox||'',String(to||''),String(cc||''),subject||'',String(body||'').replace(/<[^>]+>/g,' ')]); return {sent:true};}

module.exports={configured,redirectUri,start,callback,syncInbox,sendMail,loadIntegration};
