const crypto = require('crypto');
function key() {
  const hex = process.env.APP_ENCRYPTION_KEY || '';
  if (!/^[0-9a-fA-F]{64}$/.test(hex)) throw new Error('APP_ENCRYPTION_KEY must be 64 hex characters');
  return Buffer.from(hex, 'hex');
}
function encrypt(value) {
  if (!value) return '';
  const iv = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const enc = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  return Buffer.concat([Buffer.from('JLP1'), iv, cipher.getAuthTag(), enc]).toString('base64');
}
function decrypt(value) {
  if (!value) return '';
  const raw = Buffer.from(value, 'base64');
  if (raw.subarray(0,4).toString() !== 'JLP1') throw new Error('Unsupported encrypted value');
  const iv = raw.subarray(4,16), tag = raw.subarray(16,32), enc = raw.subarray(32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key(), iv); decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
}
module.exports = { encrypt, decrypt };
