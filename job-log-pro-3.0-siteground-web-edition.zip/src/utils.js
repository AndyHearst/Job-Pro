const crypto = require('crypto');

function nowIso() { return new Date().toISOString(); }
function safeText(v, max = 10000) { return String(v ?? '').trim().slice(0, max); }
function money(v) { const n = Number(v); return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0; }
function bool(v) { return v === true || v === 'true' || v === 1 || v === '1'; }
function token(bytes = 32) { return crypto.randomBytes(bytes).toString('base64url'); }
function hashToken(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function hmacSha256Base64(secret, body) { return crypto.createHmac('sha256', secret).update(body).digest('base64'); }
function timingSafeEqualText(a, b) {
  const aa = Buffer.from(String(a || '')); const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('='); if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function json(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
  res.end(body);
}
function readBody(req, limit = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []; let total = 0;
    req.on('data', c => { total += c.length; if (total > limit) { reject(Object.assign(new Error('Body too large'), { status: 413 })); req.destroy(); return; } chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req, limit) {
  const b = await readBody(req, limit); if (!b.length) return {};
  try { return JSON.parse(b.toString('utf8')); } catch { throw Object.assign(new Error('Invalid JSON'), { status: 400 }); }
}
function ref(prefix, id, width = 5) { return `${prefix}-${String(id).padStart(width, '0')}`; }
function addDays(date, days) { const d = new Date(date); d.setUTCDate(d.getUTCDate() + days); return d.toISOString().slice(0, 10); }

module.exports = { nowIso, safeText, money, bool, token, hashToken, hmacSha256Base64, timingSafeEqualText, parseCookies, json, readBody, readJson, ref, addDays };
