const bcrypt = require('bcryptjs');
const { query } = require('./db');
const { token, hashToken, parseCookies } = require('./utils');

const COOKIE = 'jlp_session';

async function createSession(userId) {
  const raw = token(32);
  const csrf = token(24);
  const ttl = Math.max(1, Number(process.env.SESSION_TTL_HOURS || 12));
  const expires = new Date(Date.now() + ttl * 3600 * 1000);
  await query('DELETE FROM sessions WHERE expires_at < now()');
  await query('INSERT INTO sessions(user_id, token_hash, csrf_token, expires_at) VALUES($1,$2,$3,$4)', [userId, hashToken(raw), csrf, expires]);
  return { raw, csrf, expires };
}

function cookieHeader(raw, expires) {
  const secure = String(process.env.SESSION_COOKIE_SECURE || 'true').toLowerCase() !== 'false';
  return `${COOKIE}=${encodeURIComponent(raw)}; Path=/; HttpOnly; SameSite=Lax; ${secure ? 'Secure; ' : ''}Expires=${expires.toUTCString()}`;
}
function clearCookieHeader() { return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`; }

async function getSession(req) {
  const raw = parseCookies(req.headers.cookie || '')[COOKIE];
  if (!raw) return null;
  const r = await query(`SELECT s.id session_id,s.csrf_token,s.expires_at,u.id,u.organisation_id,u.name,u.email,u.role,u.must_change_password,o.name organisation_name
    FROM sessions s JOIN users u ON u.id=s.user_id JOIN organisations o ON o.id=u.organisation_id
    WHERE s.token_hash=$1 AND s.expires_at>now() AND u.active=true`, [hashToken(raw)]);
  return r.rows[0] || null;
}

function requireRole(session, roles) {
  if (!session) throw Object.assign(new Error('Authentication required'), { status: 401 });
  if (roles && !roles.includes(session.role)) throw Object.assign(new Error('Permission denied'), { status: 403 });
}
function requireCsrf(req, session) {
  if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return;
  const value = req.headers['x-csrf-token'];
  if (!session || !value || value !== session.csrf_token) throw Object.assign(new Error('Invalid CSRF token'), { status: 403 });
}
async function verifyPassword(email, password) {
  const r = await query(`SELECT u.*,o.name organisation_name FROM users u JOIN organisations o ON o.id=u.organisation_id WHERE lower(u.email)=lower($1) AND u.active=true ORDER BY u.id LIMIT 1`, [email]);
  const u = r.rows[0]; if (!u) return null;
  return (await bcrypt.compare(password, u.password_hash)) ? u : null;
}
async function hashPassword(password) { return bcrypt.hash(password, 12); }

module.exports = { createSession, cookieHeader, clearCookieHeader, getSession, requireRole, requireCsrf, verifyPassword, hashPassword };
