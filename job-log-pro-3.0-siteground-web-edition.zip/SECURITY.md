# Security notes

Job Log Pro contains commercial, customer and potentially artwork information. Treat the application as a business system rather than a public website.

Implemented in 3.0:

- PostgreSQL tenant scoping through `organisation_id`
- bcrypt password hashing
- random server-side session tokens stored only as SHA-256 hashes
- HttpOnly / SameSite cookies and production Secure cookies
- CSRF tokens for authenticated write actions
- Content Security Policy and basic browser hardening headers
- AES-256-GCM encryption for Microsoft OAuth tokens
- WooCommerce HMAC verification over the raw webhook body
- one-way hashed public quote tokens
- private assets stored in PostgreSQL instead of the public web directory
- audit/activity table

Production requirements:

1. Use HTTPS only.
2. Keep `APP_ENCRYPTION_KEY`, DB credentials and Microsoft client secret only in SiteGround environment variables.
3. Use a strong administrator password and remove the bootstrap password after first sign-in.
4. Grant Microsoft Graph permissions no broader than required.
5. Keep SiteGround and PostgreSQL backups enabled.
6. Review user access when staff leave or roles change.
7. Do not expose database remote access to the public internet unless absolutely required.
8. Regularly review SiteGround runtime/error logs and dependency updates.

Current file-storage design stores attachments in PostgreSQL for deployment safety. For very large artwork libraries, move binary assets to dedicated object storage while retaining metadata and permission checks in PostgreSQL.
