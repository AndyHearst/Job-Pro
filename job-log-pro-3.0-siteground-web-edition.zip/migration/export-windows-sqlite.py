#!/usr/bin/env python3
"""Export the Windows Job Log Pro SQLite database to portable JSON.
Run on the Windows computer that currently hosts Job Log Pro.
"""
import json, os, sqlite3, sys, pathlib, base64

def default_db():
    local=os.environ.get('LOCALAPPDATA','')
    for name in ('joblogpro.db','job-log-pro.db','data.db'):
        p=pathlib.Path(local)/'JobLogProData'/name
        if p.exists(): return p
    return pathlib.Path(local)/'JobLogProData'/'joblogpro.db'

def encode(v):
    if isinstance(v,(bytes,bytearray)): return {'__base64__':base64.b64encode(v).decode()}
    return v

db=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else default_db()
out=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path('legacy-export.json')
if not db.exists(): raise SystemExit(f'Database not found: {db}')
c=sqlite3.connect(str(db)); c.row_factory=sqlite3.Row
names={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
want=['organisations','customers','contacts','materials','products','product_components','quotes','quote_items','sales_orders','sales_order_items','jobs','workflow_statuses','tasks','notes','proofs','invoices','invoice_items','payments','sales_order_payments','email_messages','activity_log']
data={'source':str(db),'tables':{}}
for t in want:
    if t not in names: continue
    rows=[]
    for r in c.execute(f'SELECT * FROM {t}'):
        rows.append({k:encode(r[k]) for k in r.keys()})
    data['tables'][t]=rows
out.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(f'Exported {sum(map(len,data["tables"].values()))} rows to {out.resolve()}')
