CREATE TABLE IF NOT EXISTS schema_migrations (
  version text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organisations (
  id bigserial PRIMARY KEY,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  vat_number text NOT NULL DEFAULT '',
  company_number text NOT NULL DEFAULT '',
  currency text NOT NULL DEFAULT 'GBP',
  vat_rate numeric(8,3) NOT NULL DEFAULT 20,
  address text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('administrator','manager','sales','designer','production','installer','accounts')),
  password_hash text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  must_change_password boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, email)
);

CREATE TABLE IF NOT EXISTS sessions (
  id bigserial PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  csrf_token text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS customers (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  customer_number text NOT NULL,
  company_name text NOT NULL,
  trading_name text NOT NULL DEFAULT '',
  contact_name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  website text NOT NULL DEFAULT '',
  vat_number text NOT NULL DEFAULT '',
  company_number text NOT NULL DEFAULT '',
  industry text NOT NULL DEFAULT '',
  billing_address text NOT NULL DEFAULT '',
  delivery_address text NOT NULL DEFAULT '',
  payment_terms text NOT NULL DEFAULT '30 days',
  credit_limit numeric(12,2) NOT NULL DEFAULT 0,
  price_level text NOT NULL DEFAULT 'Standard',
  account_status text NOT NULL DEFAULT 'Active',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, customer_number)
);
CREATE INDEX IF NOT EXISTS idx_customers_org_name ON customers(organisation_id, company_name);

CREATE TABLE IF NOT EXISTS contacts (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  customer_id bigint NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  name text NOT NULL,
  position text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  is_primary boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS materials (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  name text NOT NULL,
  sku text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  supplier text NOT NULL DEFAULT '',
  supplier_code text NOT NULL DEFAULT '',
  width_mm numeric(12,3) NOT NULL DEFAULT 0,
  height_mm numeric(12,3) NOT NULL DEFAULT 0,
  unit_cost numeric(12,4) NOT NULL DEFAULT 0,
  waste_pct numeric(8,3) NOT NULL DEFAULT 10,
  current_stock numeric(12,3) NOT NULL DEFAULT 0,
  minimum_stock numeric(12,3) NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS products (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  name text NOT NULL,
  sku text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  default_material_id bigint REFERENCES materials(id),
  markup_pct numeric(8,3) NOT NULL DEFAULT 70,
  minimum_price numeric(12,2) NOT NULL DEFAULT 0,
  print_rate numeric(12,4) NOT NULL DEFAULT 0,
  laminate_rate numeric(12,4) NOT NULL DEFAULT 0,
  labour_rate numeric(12,4) NOT NULL DEFAULT 35,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS product_components (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  product_id bigint NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  component_type text NOT NULL,
  name text NOT NULL,
  material_id bigint REFERENCES materials(id),
  basis text NOT NULL DEFAULT 'fixed' CHECK (basis IN ('fixed','sqm','quantity','hours','linear_m')),
  cost_rate numeric(12,4) NOT NULL DEFAULT 0,
  price_rate numeric(12,4) NOT NULL DEFAULT 0,
  setup_cost numeric(12,4) NOT NULL DEFAULT 0,
  waste_pct numeric(8,3) NOT NULL DEFAULT 0,
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS quotes (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  quote_number text NOT NULL,
  customer_id bigint NOT NULL REFERENCES customers(id),
  job_title text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  quote_date date NOT NULL DEFAULT CURRENT_DATE,
  expiry_date date,
  next_contact_date date,
  required_date date,
  salesperson_id bigint REFERENCES users(id),
  customer_reference text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  discount numeric(12,2) NOT NULL DEFAULT 0,
  delivery numeric(12,2) NOT NULL DEFAULT 0,
  installation numeric(12,2) NOT NULL DEFAULT 0,
  public_token_hash text,
  public_token_encrypted text NOT NULL DEFAULT '',
  viewed_at timestamptz,
  accepted_at timestamptz,
  accepted_by text NOT NULL DEFAULT '',
  accepted_ip text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, quote_number)
);
CREATE INDEX IF NOT EXISTS idx_quotes_org_status ON quotes(organisation_id,status);

CREATE TABLE IF NOT EXISTS quote_items (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  quote_id bigint NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  product_id bigint REFERENCES products(id),
  line_number integer NOT NULL DEFAULT 1,
  description text NOT NULL,
  width_mm numeric(12,3) NOT NULL DEFAULT 0,
  height_mm numeric(12,3) NOT NULL DEFAULT 0,
  quantity numeric(12,3) NOT NULL DEFAULT 1,
  unit text NOT NULL DEFAULT 'Each',
  unit_discount_pct numeric(8,3) NOT NULL DEFAULT 0,
  material text NOT NULL DEFAULT '',
  sides text NOT NULL DEFAULT 'Single Sided',
  print_type text NOT NULL DEFAULT '',
  laminate text NOT NULL DEFAULT '',
  finishing text NOT NULL DEFAULT '',
  estimated_cost numeric(12,2) NOT NULL DEFAULT 0,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  line_total numeric(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sales_orders (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  order_number text NOT NULL,
  quote_id bigint REFERENCES quotes(id),
  customer_id bigint NOT NULL REFERENCES customers(id),
  title text NOT NULL,
  status text NOT NULL DEFAULT 'new',
  order_date date NOT NULL DEFAULT CURRENT_DATE,
  required_date date,
  salesperson_id bigint REFERENCES users(id),
  customer_reference text NOT NULL DEFAULT '',
  customer_po text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, order_number)
);
CREATE INDEX IF NOT EXISTS idx_sales_orders_org_status ON sales_orders(organisation_id,status);

CREATE TABLE IF NOT EXISTS sales_order_items (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  sales_order_id bigint NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
  quote_item_id bigint REFERENCES quote_items(id),
  product_id bigint REFERENCES products(id),
  line_number integer NOT NULL DEFAULT 1,
  description text NOT NULL,
  width_mm numeric(12,3) NOT NULL DEFAULT 0,
  height_mm numeric(12,3) NOT NULL DEFAULT 0,
  quantity numeric(12,3) NOT NULL DEFAULT 1,
  unit text NOT NULL DEFAULT 'Each',
  unit_discount_pct numeric(8,3) NOT NULL DEFAULT 0,
  material text NOT NULL DEFAULT '',
  sides text NOT NULL DEFAULT 'Single Sided',
  print_type text NOT NULL DEFAULT '',
  laminate text NOT NULL DEFAULT '',
  finishing text NOT NULL DEFAULT '',
  estimated_cost numeric(12,2) NOT NULL DEFAULT 0,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  line_total numeric(12,2) NOT NULL DEFAULT 0,
  production_status text NOT NULL DEFAULT 'not_started',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_statuses (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  code text NOT NULL,
  name text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  colour text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  terminal boolean NOT NULL DEFAULT false,
  UNIQUE(organisation_id, code)
);

CREATE TABLE IF NOT EXISTS jobs (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  job_number text NOT NULL,
  source_type text NOT NULL DEFAULT 'sales_order' CHECK (source_type IN ('quote','sales_order','direct')),
  quote_id bigint REFERENCES quotes(id),
  sales_order_id bigint REFERENCES sales_orders(id),
  sales_order_item_id bigint REFERENCES sales_order_items(id),
  customer_id bigint NOT NULL REFERENCES customers(id),
  title text NOT NULL,
  status text NOT NULL DEFAULT 'design',
  priority text NOT NULL DEFAULT 'normal',
  due_date date,
  production_due_date date,
  installation_date date,
  salesperson_id bigint REFERENCES users(id),
  project_manager_id bigint REFERENCES users(id),
  assigned_user_id bigint REFERENCES users(id),
  customer_reference text NOT NULL DEFAULT '',
  purchase_order text NOT NULL DEFAULT '',
  production_notes text NOT NULL DEFAULT '',
  estimated_cost numeric(12,2) NOT NULL DEFAULT 0,
  selling_price numeric(12,2) NOT NULL DEFAULT 0,
  actual_cost numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, job_number)
);
CREATE INDEX IF NOT EXISTS idx_jobs_org_status ON jobs(organisation_id,status);
CREATE INDEX IF NOT EXISTS idx_jobs_order ON jobs(organisation_id,sales_order_id);

CREATE TABLE IF NOT EXISTS job_source_items (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  job_id bigint NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  quote_item_id bigint REFERENCES quote_items(id),
  sales_order_item_id bigint REFERENCES sales_order_items(id),
  CHECK (quote_item_id IS NOT NULL OR sales_order_item_id IS NOT NULL)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_job_source_quote ON job_source_items(job_id,quote_item_id) WHERE quote_item_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_job_source_order ON job_source_items(job_id,sales_order_item_id) WHERE sales_order_item_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS proofs (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  job_id bigint NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  proof_number text NOT NULL,
  version integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'pending',
  message text NOT NULL DEFAULT '',
  public_token_hash text,
  file_name text NOT NULL DEFAULT '',
  file_mime text NOT NULL DEFAULT '',
  file_data bytea,
  sent_at timestamptz,
  decided_at timestamptz,
  decided_by text NOT NULL DEFAULT '',
  decision_ip text NOT NULL DEFAULT '',
  comment text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, proof_number)
);

CREATE TABLE IF NOT EXISTS tasks (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  entity_id bigint NOT NULL,
  title text NOT NULL,
  assigned_user_id bigint REFERENCES users(id),
  due_at timestamptz,
  status text NOT NULL DEFAULT 'open',
  created_by bigint REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_tasks_entity ON tasks(organisation_id,entity_type,entity_id,status);

CREATE TABLE IF NOT EXISTS notes (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  entity_id bigint NOT NULL,
  body text NOT NULL,
  visibility text NOT NULL DEFAULT 'internal',
  created_by bigint REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assets (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  entity_id bigint NOT NULL,
  original_name text NOT NULL,
  mime_type text NOT NULL DEFAULT 'application/octet-stream',
  size_bytes integer NOT NULL,
  category text NOT NULL DEFAULT 'attachment',
  version integer NOT NULL DEFAULT 1,
  approved boolean NOT NULL DEFAULT false,
  uploaded_by bigint REFERENCES users(id),
  data bytea NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_assets_entity ON assets(organisation_id,entity_type,entity_id);

CREATE TABLE IF NOT EXISTS invoices (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  invoice_number text NOT NULL,
  customer_id bigint NOT NULL REFERENCES customers(id),
  job_id bigint REFERENCES jobs(id),
  sales_order_id bigint REFERENCES sales_orders(id),
  status text NOT NULL DEFAULT 'draft',
  issue_date date NOT NULL DEFAULT CURRENT_DATE,
  due_date date,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  posted boolean NOT NULL DEFAULT false,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, invoice_number)
);
CREATE INDEX IF NOT EXISTS idx_invoices_org_status ON invoices(organisation_id,status);

CREATE TABLE IF NOT EXISTS invoice_items (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  invoice_id bigint NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL DEFAULT 1,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  line_total numeric(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payments (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  invoice_id bigint NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  payment_date date NOT NULL DEFAULT CURRENT_DATE,
  amount numeric(12,2) NOT NULL,
  method text NOT NULL DEFAULT 'Bank transfer',
  reference text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sales_order_payments (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  sales_order_id bigint NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
  payment_date date NOT NULL DEFAULT CURRENT_DATE,
  amount numeric(12,2) NOT NULL,
  method text NOT NULL DEFAULT 'Bank transfer',
  reference text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_messages (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  user_id bigint REFERENCES users(id),
  direction text NOT NULL,
  account_email text NOT NULL DEFAULT '',
  from_address text NOT NULL,
  to_addresses text NOT NULL DEFAULT '',
  cc_addresses text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT '',
  body_text text NOT NULL DEFAULT '',
  provider_message_id text NOT NULL DEFAULT '',
  thread_key text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'received',
  error text NOT NULL DEFAULT '',
  unread boolean NOT NULL DEFAULT false,
  customer_id bigint REFERENCES customers(id),
  entity_type text NOT NULL DEFAULT '',
  entity_id bigint,
  received_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_email_provider_message ON email_messages(organisation_id,provider_message_id) WHERE provider_message_id <> '';

CREATE TABLE IF NOT EXISTS integrations (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  provider text NOT NULL,
  config_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  secrets_encrypted text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organisation_id, provider)
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id bigserial PRIMARY KEY,
  organisation_id bigint REFERENCES organisations(id) ON DELETE CASCADE,
  provider text NOT NULL,
  external_id text NOT NULL,
  event_type text NOT NULL DEFAULT '',
  payload jsonb NOT NULL,
  status text NOT NULL DEFAULT 'received',
  error text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider, external_id)
);

CREATE TABLE IF NOT EXISTS activity_log (
  id bigserial PRIMARY KEY,
  organisation_id bigint NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  user_id bigint REFERENCES users(id),
  entity_type text NOT NULL,
  entity_id bigint,
  action text NOT NULL,
  detail text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activity_org_created ON activity_log(organisation_id,created_at DESC);
