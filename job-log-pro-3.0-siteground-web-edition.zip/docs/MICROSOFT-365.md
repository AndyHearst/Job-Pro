# Microsoft 365 / Outlook setup

Job Log Pro 3.0 uses OAuth 2.0 and Microsoft Graph. It does not store the mailbox password.

## Redirect URI

For the recommended domain use:

`https://app.easysafetysigns.co.uk/api/integrations/microsoft365/callback`

## Entra app registration

Create an app registration in Microsoft Entra and configure a Web redirect URI matching the URL above.

Add delegated permissions:

- User.Read
- Mail.Read
- Mail.Send
- offline_access

For a shared mailbox also add:

- Mail.Read.Shared
- Mail.Send.Shared

The signed-in user must also have the appropriate Exchange permissions for the shared mailbox.

Create a client secret and put these values into SiteGround environment variables:

- `MICROSOFT_TENANT_ID`
- `MICROSOFT_CLIENT_ID`
- `MICROSOFT_CLIENT_SECRET`
- optional `MICROSOFT_SHARED_MAILBOX`

Then sign in to Job Log Pro as an administrator and open **Email → Connect Microsoft 365**.

Tokens are encrypted before being stored in PostgreSQL using `APP_ENCRYPTION_KEY`.
