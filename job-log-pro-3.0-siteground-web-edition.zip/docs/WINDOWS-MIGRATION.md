# Migrate your existing Windows Job Log Pro data

The safest migration is export → inspect → import. Keep the Windows installation untouched until the SiteGround copy has been checked.

## A. On the Windows Job Log Pro computer

Copy `migration/export-windows-sqlite.py` onto the Windows computer and run:

```bat
python migration\export-windows-sqlite.py
```

By default it looks under:

`%LOCALAPPDATA%\JobLogProData\`

and creates:

`legacy-export.json`

If the database has a different location:

```bat
python migration\export-windows-sqlite.py "C:\path\joblogpro.db" "C:\path\legacy-export.json"
```

## B. Transfer the JSON securely

Do not email the export: it may contain customer/contact/job/email data. Transfer it securely to the SiteGround project over SSH/SFTP/File Manager and remove it after the import is verified.

## C. On SiteGround

First deploy Job Log Pro 3.0 and run migrations/seed. Then:

```bash
npm run import-legacy -- legacy-export.json
```

The importer currently migrates the core commercial/production records:

- customers
- products
- quotes and quote items
- sales orders and order items
- jobs
- invoices and invoice items
- payments

It intentionally does not import the old Windows login/session secrets or Microsoft 365 OAuth tokens. Create/reset the web administrator and reconnect Microsoft 365 after migration.

## D. Reconciliation

Before switching production use, compare at minimum:

- customer count
- open quotes
- open sales orders
- current production jobs
- invoice count and balances
- several recent orders end-to-end

Keep the Windows database backup until the web deployment has run successfully through a complete production cycle.
