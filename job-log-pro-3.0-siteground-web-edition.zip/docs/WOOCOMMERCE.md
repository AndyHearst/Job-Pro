# WooCommerce integration

Job Log Pro exposes a signed WooCommerce webhook endpoint:

`https://app.easysafetysigns.co.uk/api/webhooks/woocommerce/order-paid`

## Configure

1. Generate a strong random webhook secret.
2. Put it in SiteGround as `WOOCOMMERCE_WEBHOOK_SECRET`.
3. In WooCommerce create an order webhook that fires when an order is paid/processed (use the event most appropriate to your store workflow).
4. Set the delivery URL to the endpoint above.
5. Use exactly the same secret in WooCommerce and Job Log Pro.

Job Log Pro verifies the WooCommerce HMAC signature against the raw request body.

## Import behaviour

A valid WooCommerce order:

- matches an existing customer by billing email, or creates a new customer;
- creates a Job Log Pro Sales Order;
- copies WooCommerce line items to Sales Order Items;
- stores useful variation/meta information in material/finishing fields;
- prevents duplicate imports using the WooCommerce order ID.

If `WOOCOMMERCE_AUTO_CREATE_JOBS=true`, each imported Sales Order Item also creates its own production Job. Keep this `false` initially if you want staff to review web orders before they reach production.

## QR reorder

The WooCommerce endpoint is compatible with adding the secure per-order-line QR reorder workflow later. Do not embed customer details or raw order data directly in a QR URL; use an unguessable reorder token mapped to a saved production specification.
